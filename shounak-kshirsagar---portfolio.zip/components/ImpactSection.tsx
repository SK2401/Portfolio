
import React from 'react';
import SectionWrapper from './SectionWrapper';

interface KpiCardProps {
  value: string;
  label: string;
  description: string;
}

const KpiCard: React.FC<KpiCardProps> = ({ value, label, description }) => (
  <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-6 rounded-lg shadow-lg text-white text-center transform hover:scale-105 transition-transform duration-300">
    <div className="text-4xl font-bold mb-2">{value}</div>
    <div className="text-lg font-semibold mb-2">{label}</div>
    <p className="text-sm opacity-80">{description}</p>
  </div>
);

const ImpactSection: React.FC = () => {
  const kpis = [
    { value: "$6M+", label: "Sourcing Value Created", description: "Achieved through strategic sourcing and negotiation initiatives." },
    { value: "80%", label: "PO Flow Automated", description: "Streamlining procurement operations via custom automation frameworks." },
    { value: "25%", label: "Inventory Reduction", description: "Optimizing stock levels while maintaining service levels." },
    { value: "15+", label: "Decision Tools Built", description: "Custom analytics and tools delivered for enhanced decision-making." }
  ];

  return (
    <SectionWrapper id="impact" className="bg-white" ariaLabelledBy="impact-title">
      <div className="text-center mb-12 md:mb-16">
        <h2 id="impact-title" className="text-3xl md:text-4xl font-bold text-brand-dark mb-4">
          Quantifiable Results & Real-World Impact
        </h2>
        <p className="text-lg text-brand-medium max-w-2xl mx-auto">
          Delivering measurable improvements and tangible value through data-driven solutions.
        </p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
        {kpis.map((kpi, index) => (
          <KpiCard key={index} value={kpi.value} label={kpi.label} description={kpi.description} />
        ))}
      </div>
      <div className="text-center mt-12">
        <a 
          href="#contact" 
          className="text-brand-primary font-semibold hover:underline text-lg"
           onClick={(e) => {
                e.preventDefault();
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
        >
          Explore Case Studies (Coming Soon) &rarr;
        </a>
      </div>
    </SectionWrapper>
  );
};

export default ImpactSection;
