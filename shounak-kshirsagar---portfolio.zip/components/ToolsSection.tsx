
import React from 'react';
import SectionWrapper from './SectionWrapper';

interface ToolPreviewCardProps {
  title: string;
  description: string;
  imageUrl: string;
  tags: string[];
}

const ToolPreviewCard: React.FC<ToolPreviewCardProps> = ({ title, description, imageUrl, tags }) => (
  <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl group">
    <img src={imageUrl} alt={title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
    <div className="p-6">
      <h3 className="text-xl font-semibold text-brand-dark mb-2">{title}</h3>
      <div className="mb-3">
        {tags.map(tag => (
          <span key={tag} className="inline-block bg-indigo-100 text-indigo-700 text-xs font-semibold mr-2 px-2.5 py-0.5 rounded-full">{tag}</span>
        ))}
      </div>
      <p className="text-brand-medium text-sm mb-4">{description}</p>
      <button 
        className="w-full bg-brand-secondary text-white font-medium py-2 px-4 rounded-lg hover:bg-emerald-600 transition-colors duration-300"
        onClick={() => alert(`Preview for '${title}' coming soon!`)}
      >
        Try Demo / Learn More
      </button>
    </div>
  </div>
);

const ToolsSection: React.FC = () => {
  const tools = [
    {
      title: "Automated RFQ Analyzer",
      description: "Parses RFQ responses, compares bids, and highlights optimal sourcing options based on custom criteria.",
      imageUrl: "https://picsum.photos/seed/tool1/400/300",
      tags: ["Automation", "Sourcing", "Analytics"]
    },
    {
      title: "Dynamic Inventory Modeler",
      description: "Simulates inventory scenarios based on demand forecasts, lead times, and service level targets.",
      imageUrl: "https://picsum.photos/seed/tool2/400/300",
      tags: ["Forecasting", "Simulation", "Optimization"]
    },
    {
      title: "Supplier KPI Dashboard",
      description: "Consolidates supplier performance data into an interactive dashboard for easy monitoring and evaluation.",
      imageUrl: "https://picsum.photos/seed/tool3/400/300",
      tags: ["Dashboard", "KPI", "SRM"]
    }
  ];

  return (
    <SectionWrapper id="tools" className="bg-brand-light" ariaLabelledBy="tools-title">
      <div className="text-center mb-12 md:mb-16">
        <h2 id="tools-title" className="text-3xl md:text-4xl font-bold text-brand-dark mb-4">
          My Digital Toolkit & Lab
        </h2>
        <p className="text-lg text-brand-medium max-w-2xl mx-auto">
          A glimpse into the custom tools I've built to solve real-world supply chain problems. Some are available for demo.
        </p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {tools.map((tool, index) => (
          <ToolPreviewCard key={index} {...tool} />
        ))}
      </div>
    </SectionWrapper>
  );
};

export default ToolsSection;
