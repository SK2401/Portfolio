
import React, { useEffect, useRef, useState } from 'react';
import SectionWrapper from './SectionWrapper';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  category: string;
  accentName: 'primary' | 'secondary'; // Tertiary removed
  ctaText: string;
  ctaLink: string;
  isVisible: boolean;
  index: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, category, accentName, ctaText, ctaLink, isVisible, index }) => {
  const accentColorVariants = {
    primary: {
      text: 'text-brand-primary',
      bgMuted: 'bg-brand-primary/10',
      border: 'border-brand-primary',
      hoverText: 'hover:text-blue-400', // Kept as a generic lighter blue, as brand.primary is now Blue-500
    },
    secondary: {
      text: 'text-brand-secondary',
      bgMuted: 'bg-brand-secondary/10',
      border: 'border-brand-secondary',
      hoverText: 'hover:text-emerald-400', // Kept as a generic lighter emerald
    }
    // Tertiary case removed
  };
  const accents = accentColorVariants[accentName] || accentColorVariants.primary;

  const smoothScrollTo = (selector: string) => (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const targetId = selector.substring(1);
    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  };


  return (
    <a 
      href={ctaLink} 
      onClick={ctaLink.startsWith('#') ? smoothScrollTo(ctaLink) : undefined}
      className={`group flex flex-col bg-dark-bg-card p-6 md:p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02] ${accents.border} border-t-2 md:border-l-2 md:border-t-0 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
      style={{ transitionDelay: `${index * 100}ms` }} // Staggered animation
      target={ctaLink.startsWith('#') ? '_self' : '_blank'}
      rel={ctaLink.startsWith('#') ? '' : 'noopener noreferrer'}
    >
      <div className={`mb-5 flex items-center justify-between`}>
        <div className={`p-3 rounded-full ${accents.bgMuted} ${accents.text}`}>
          {icon}
        </div>
        <span className={`text-xs font-semibold uppercase tracking-wider ${accents.text}`}>{category}</span>
      </div>
      <h3 className="text-xl font-semibold text-dark-text-high mb-3">{title}</h3>
      <p className="text-dark-text-medium text-sm flex-grow mb-6">{description}</p>
      <span className={`mt-auto font-medium ${accents.text} ${accents.hoverText} transition-colors duration-300 self-start`}>
        {ctaText} &rarr;
      </span>
    </a>
  );
};

const ServicesSection: React.FC = () => {
  const services = [
    {
      title: "Supply Chain Optimization",
      description: "End-to-end analysis and redesign of supply chain processes for enhanced efficiency and resilience.",
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 12h16.5m-16.5 3.75h16.5M3.75 19.5h16.5M5.625 4.5h12.75a1.875 1.875 0 010 3.75H5.625a1.875 1.875 0 010-3.75z" /></svg>,
      category: "Strategy",
      accentName: 'primary' as 'primary',
      ctaText: "Explore Strategies",
      ctaLink: "#contact"
    },
    {
      title: "Procurement Transformation",
      description: "Developing strategic sourcing plans and supplier relationship frameworks to maximize value.",
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 10.5a3 3 0 11-6 0 3 3 0 016 0zm3 0h.008v.008H18V10.5zm-12 0h.008v.008H6V10.5z" /></svg>,
      category: "Consulting",
      accentName: 'secondary' as 'secondary',
      ctaText: "Discuss Solutions",
      ctaLink: "#contact"
    },
    {
      title: "Custom Analytics & Tools",
      description: "Building bespoke dashboards, KPI trackers, and automation tools tailored to your specific needs.",
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>,
      category: "Development",
      accentName: 'primary' as 'primary', // Reverted from tertiary
      ctaText: "View Tool Demos",
      ctaLink: "#tools"
    },
    {
      title: "Data Strategy & Insights",
      description: "Helping businesses turn raw data into actionable intelligence and a competitive edge.",
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M7.5 14.25v2.25m3-4.5v4.5m3-6.75v6.75m3-9v9M6 20.25h12A2.25 2.25 0 0020.25 18V6A2.25 2.25 0 0018 3.75H6A2.25 2.25 0 003.75 6v12A2.25 2.25 0 006 20.25z" /></svg>,
      category: "Analytics",
      accentName: 'primary' as 'primary',
      ctaText: "Unlock Insights",
      ctaLink: "#contact"
    },
    {
      title: "Process Automation",
      description: "Designing and implementing automated workflows to reduce manual effort and improve accuracy.",
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" /></svg>,
      category: "Automation",
      accentName: 'secondary' as 'secondary',
      ctaText: "Automate Now",
      ctaLink: "#contact"
    },
    {
      title: "Interactive Dashboard Design",
      description: "Creating intuitive and visually compelling dashboards for real-time monitoring and decision support.",
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25m18 0A2.25 2.25 0 0018.75 3H5.25A2.25 2.25 0 003 5.25m18 0V12a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 12V5.25" /></svg>,
      category: "UX/UI Design",
      accentName: 'secondary' as 'secondary', // Reverted from tertiary
      ctaText: "Visualize Data",
      ctaLink: "#contact"
    }
  ];

  const sectionRef = useRef<HTMLElement>(null);
  const [cardsVisible, setCardsVisible] = useState<boolean[]>(new Array(services.length).fill(false));
  const [titleVisible, setTitleVisible] = useState(false);
  const [ctaVisible, setCtaVisible] = useState(false);


  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -50px 0px"
    };

    const observers: IntersectionObserver[] = [];

    const titleObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) setTitleVisible(true);
      });
    }, observerOptions);
    
    const titleElement = sectionRef.current?.querySelector('#services-title-block');
    if (titleElement) titleObserver.observe(titleElement);
    observers.push(titleObserver);

    const cardElements = sectionRef.current?.querySelectorAll('.service-card-anchor');
    cardElements?.forEach((el, index) => {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            setCardsVisible(prev => {
              const newVisible = [...prev];
              newVisible[index] = true;
              return newVisible;
            });
          }
        });
      }, observerOptions);
      observer.observe(el);
      observers.push(observer);
    });
    
    const ctaObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) setCtaVisible(true);
      });
    }, {...observerOptions, threshold: 0.3});

    const ctaElement = sectionRef.current?.querySelector('#services-cta-block');
    if (ctaElement) ctaObserver.observe(ctaElement);
    observers.push(ctaObserver);


    return () => {
      observers.forEach(obs => obs.disconnect());
    };
  }, []);
  
  const smoothScrollToContact = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <SectionWrapper ref={sectionRef} id="services" className="bg-dark-bg-main text-dark-text-high" ariaLabelledBy="services-title">
      <div id="services-title-block" className={`text-center mb-12 md:mb-16 transition-all duration-700 ease-out ${titleVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <h2 id="services-title" className="text-3xl md:text-4xl font-bold text-dark-text-high mb-4">
          What I Offer
        </h2>
        <p className="text-lg text-dark-text-medium max-w-2xl mx-auto">
          My packaged data analytics, strategy, and tool development solutions.
        </p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service, index) => (
          // Added a wrapper div for IntersectionObserver to target
          <div key={index} className="service-card-anchor">
            <ServiceCard {...service} isVisible={cardsVisible[index]} index={index} />
          </div>
        ))}
      </div>
      <div id="services-cta-block" className={`mt-16 md:mt-24 text-center transition-all duration-700 ease-out ${ctaVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <h3 className="text-2xl md:text-3xl font-semibold text-dark-text-high mb-4">
          Ready to Transform Your Supply Chain?
        </h3>
        <p className="text-dark-text-medium mb-8 max-w-xl mx-auto">
          Let's discuss how these services can be tailored to your unique challenges and drive measurable results for your business.
        </p>
        <a
          href="#contact"
          onClick={smoothScrollToContact}
          className="inline-block bg-brand-primary text-white font-medium py-3 px-10 rounded-lg shadow-md hover:bg-brand-primary-hover transition-all duration-300 text-lg transform hover:scale-105"
          role="button"
        >
          Contact Me
        </a>
      </div>
    </SectionWrapper>
  );
};

export default ServicesSection;
