
import React from 'react';

interface SectionWrapperProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  ariaLabelledBy?: string;
}

// Fix: Use React.forwardRef to allow passing refs to the underlying section element
const SectionWrapper = React.forwardRef<HTMLElement, SectionWrapperProps>(
  ({ children, className = '', id, ariaLabelledBy }, ref) => {
    return (
      <section ref={ref} id={id} aria-labelledby={ariaLabelledBy} className={`py-16 md:py-24 ${className}`}>
        <div className="container mx-auto px-6 md:px-8 max-w-6xl">
          {children}
        </div>
      </section>
    );
  }
);

SectionWrapper.displayName = 'SectionWrapper'; // Optional: for better debugging

export default SectionWrapper;