import React, { useState, useEffect } from 'react';

// --- SVG Icon Components ---
// UserCircleIcon is removed as it's replaced by an img tag.

const ArrowRightMiniIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z" clipRule="evenodd" />
  </svg>
);
// --- End SVG Icon Components ---


const HeroSection: React.FC = () => {
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 1000);
    setCurrentTime(new Date().toLocaleTimeString('en-GB', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })); // Initial set
    return () => clearInterval(timer);
  }, []);
  
  const smoothScrollTo = (selector: string) => (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => {
    e.preventDefault();
    const targetId = selector.substring(1);
    const targetElement = document.getElementById(targetId);
    if (targetElement) {
      const headerElement = document.querySelector('header.fixed'); 
      const headerHeight = headerElement?.clientHeight || 0;
      const elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - headerHeight - 20; 
      
      window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
      });
    }
  };

  return (
    <section
      id="hero"
      aria-labelledby="hero-title-main"
      className="relative min-h-screen flex flex-col text-white overflow-hidden"
      style={{ background: 'radial-gradient(ellipse at center top, #1a2035 0%, #0a0d16 70%)' }}
    >
      {/* Top Bar within Hero - Simplified */}
      <div className="w-full px-4 sm:px-6 md:px-10 py-4 flex justify-between items-center z-20 shrink-0">
        <div className="text-sm font-medium text-gray-300 w-auto">Pune, India</div>
        <div className="text-sm font-medium text-gray-300 w-auto text-right">{currentTime}</div>
      </div>
      
      {/* Main Content Area */}
      <div className="flex-grow flex flex-col justify-center items-center text-center z-10 px-6 md:px-8 pb-10 sm:pb-16 pt-8 sm:pt-12 md:pt-16"> 
        <div className="inline-block bg-[#0F2738] text-[#5EEAD4] text-xs font-semibold px-4 py-1.5 rounded-full mb-6 md:mb-8 shadow">
          Key Focus: Supply Chain Transformation
        </div>

        <h1
          id="hero-title-main"
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 md:mb-8 leading-tight"
        >
          Engineering Impactful Supply Chain Solutions.
        </h1>
        <p className="text-base sm:text-lg md:text-xl text-gray-300 mb-10 md:mb-12 max-w-2xl mx-auto">
          I merge industrial engineering expertise with data-driven strategies to optimize procurement, streamline operations, and build custom tools for measurable business growth.
        </p>

        <a
          href="#about"
          onClick={smoothScrollTo('#about')}
          className="group inline-flex items-center bg-black/40 hover:bg-black/60 backdrop-blur-md text-gray-100 hover:text-white font-medium py-2 px-4 sm:py-2.5 sm:px-5 rounded-full shadow-xl transition-all duration-300 text-sm sm:text-base border border-white/20 hover:border-white/30"
          role="button"
        >
          <img 
            src="https://i.pravatar.cc/160?u=shounak" 
            alt="Shounak K." 
            className="w-6 h-6 sm:w-7 sm:h-7 rounded-full border-2 border-slate-500/60 group-hover:border-slate-400/80 transition-colors" 
          />
          <span className="ml-2 sm:ml-2.5">About - Shounak K.</span>
          <ArrowRightMiniIcon className="ml-1.5 w-4 h-4 hidden group-hover:inline-block transition-all duration-200 transform group-hover:translate-x-0.5 opacity-0 group-hover:opacity-100" />
        </a>
      </div>
    </section>
  );
};

export default HeroSection;