
import React, { useState } from 'react';
import SectionWrapper from './SectionWrapper';

const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      alert("Please fill in all fields.");
      return;
    }
    // Here you would typically send the form data to a backend or email service
    console.log("Form submitted:", formData);
    setIsSubmitted(true);
    // Reset form after a delay for user to see message
    setTimeout(() => {
        setFormData({ name: '', email: '', message: '' });
        setIsSubmitted(false);
    }, 5000);
  };

  return (
    <SectionWrapper id="contact" className="bg-white" ariaLabelledBy="contact-title">
      <div className="text-center mb-12 md:mb-16">
        <h2 id="contact-title" className="text-3xl md:text-4xl font-bold text-brand-dark mb-4">
          Let's Connect & Collaborate
        </h2>
        <p className="text-lg text-brand-medium max-w-2xl mx-auto">
          Whether you have a project in mind, want to explore my tools, or just want to discuss supply chain innovation, I'd love to hear from you.
        </p>
      </div>
      
      {isSubmitted ? (
        <div className="text-center p-8 bg-emerald-50 border border-emerald-300 rounded-lg">
          <h3 className="text-2xl font-semibold text-emerald-700 mb-2">Thank you!</h3>
          <p className="text-emerald-600">Your message has been sent. I'll be in touch shortly.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="max-w-xl mx-auto bg-slate-50 p-8 md:p-10 rounded-xl shadow-xl space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-brand-dark mb-1">Full Name</label>
            <input 
              type="text" 
              name="name" 
              id="name" 
              value={formData.name}
              onChange={handleChange}
              required 
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-brand-primary focus:border-brand-primary transition-colors" 
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-brand-dark mb-1">Email Address</label>
            <input 
              type="email" 
              name="email" 
              id="email" 
              value={formData.email}
              onChange={handleChange}
              required 
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-brand-primary focus:border-brand-primary transition-colors" 
            />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-brand-dark mb-1">Message</label>
            <textarea 
              name="message" 
              id="message" 
              rows={4} 
              value={formData.message}
              onChange={handleChange}
              required 
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-brand-primary focus:border-brand-primary transition-colors"
            ></textarea>
          </div>
          <div>
            <button 
              type="submit" 
              className="w-full bg-brand-primary text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-blue-700 transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary"
            >
              Send Message
            </button>
          </div>
        </form>
      )}
    </SectionWrapper>
  );
};

export default ContactSection;
