
import React, { useState, useEffect, useRef, useCallback } from 'react';
import SectionWrapper from './SectionWrapper';

// --- Helper Hook for prefers-reduced-motion ---
const usePrefersReducedMotion = () => {
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    const handleChange = () => {
      setPrefersReducedMotion(mediaQuery.matches);
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);
  return prefersReducedMotion;
};

// --- Helper Hook for Intersection Observer ---
const useIntersectionObserver = (options: IntersectionObserverInit) => {
  const [entry, setEntry] = useState<IntersectionObserverEntry | null>(null);
  const [node, setNode] = useState<HTMLElement | null>(null);
  const observer = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(([entry]) => setEntry(entry), options);
    const { current: currentObserver } = observer;
    if (node) currentObserver.observe(node);
    return () => currentObserver.disconnect();
  }, [node, options]);

  return [setNode, entry] as const;
};

// --- SVG Icon Components for IntroSubSection ---
const MapPinIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M9.69 18.933l.003.001C9.89 19.02 10 19 10 19s.11.02.308-.066l.002-.001.006-.003.018-.008a5.741 5.741 0 00.281-.145l.002-.001L10.327 18.5l.006-.004.011-.007.004-.002.003-.002A4.235 4.235 0 0013.5 14.25c0-2.072-1.568-3.75-3.5-3.75S6.5 12.178 6.5 14.25a4.235 4.235 0 003.261 4.165l.003.002.004.002.011.007.006.004 1.03.655a5.741 5.741 0 00.28.145l.002.001.018.008.006.003zM10 11.25a3 3 0 100 6 3 3 0 000-6z" clipRule="evenodd" />
  </svg>
);

const CalendarDaysIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M5.75 2a.75.75 0 01.75.75V4h7V2.75a.75.75 0 011.5 0V4h.25A2.75 2.75 0 0118 6.75v8.5A2.75 2.75 0 0115.25 18H4.75A2.75 2.75 0 012 15.25v-8.5A2.75 2.75 0 014.75 4H5V2.75A.75.75 0 015.75 2zm-1 5.5c-.69 0-1.25.56-1.25 1.25v6.5c0 .69.56 1.25 1.25 1.25h10.5c.69 0 1.25-.56 1.25-1.25v-6.5c0-.69-.56-1.25-1.25-1.25H4.75z" clipRule="evenodd" />
  </svg>
);

const ChevronRightIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clipRule="evenodd" />
  </svg>
);

const GitHubIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
    <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
  </svg>
);

const LinkedInIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"></path>
  </svg>
);

const EnvelopeIconLocal: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path d="M3 4a2 2 0 00-2 2v8a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2H3zm12 2L10 10 5 6h10z" />
    <path d="M3 6l7 5.5L17 6v2l-7 5.5L3 8V6z" />
  </svg>
);


// --- SVG Icon Components for Skills & CTA (existing) ---
const CubeTransparentIcon: React.FC<{ className?: string }> = ({ className = "w-12 h-12" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" />
  </svg>
);

const ShoppingBagIcon: React.FC<{ className?: string }> = ({ className = "w-12 h-12" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
  </svg>
);

const CommandLineIcon: React.FC<{ className?: string }> = ({ className = "w-12 h-12" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 7.5l3 2.25-3 2.25m4.5 0h3m-9 8.25h13.5A2.25 2.25 0 0021 18V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v12a2.25 2.25 0 002.25 2.25z" />
  </svg>
);

const ArrowRightCircleIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5 ml-2" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 15l3-3m0 0l-3-3m3 3h-7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

// --- Animated Component Wrapper ---
interface AnimatedItemProps {
  children: React.ReactNode;
  prefersReducedMotion: boolean;
  delay?: string;
  className?: string;
  threshold?: number;
  initialY?: number;
  initialX?: number;
}

const AnimatedItem: React.FC<AnimatedItemProps> = ({ children, prefersReducedMotion, delay = '0ms', className = '', threshold = 0.1, initialY = 20, initialX = 0 }) => {
  const [ref, entry] = useIntersectionObserver({ threshold });
  const isVisible = entry?.isIntersecting;

  const xTransform = initialX !== 0 ? `translateX(${initialX}px)` : '';
  const yTransform = initialY !== 0 ? `translateY(${initialY}px)` : '';

  return (
    <div
      ref={ref}
      style={{ transitionDelay: prefersReducedMotion ? '0ms' : delay }}
      className={`transition-all duration-700 ease-out ${className} ${
        isVisible && !prefersReducedMotion
          ? 'opacity-100 translate-y-0 translate-x-0'
          : prefersReducedMotion 
          ? 'opacity-100'
          : `opacity-0 ${xTransform} ${yTransform}`
      }`}
    >
      {children}
    </div>
  );
};


// --- Intro Sub-Section ---
interface IntroSubSectionProps {
  prefersReducedMotion: boolean;
  smoothScrollTo: (selector: string) => (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => void;
}

const IntroSubSection: React.FC<IntroSubSectionProps> = ({ prefersReducedMotion, smoothScrollTo }) => {
  const GITHUB_URL = "https://github.com/shounak-kshirsagar"; // Replace with actual URL
  const LINKEDIN_URL = "https://www.linkedin.com/in/shounak-kshirsagar/"; // Replace with actual URL
  const AVATAR_URL = "/images/sk.jpg"; // Path to local image file in images folder

  return (
    <div className="min-h-screen flex flex-col items-center justify-center py-12 md:py-16 lg:py-20 text-dark-text-high relative overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="md:flex md:flex-row md:items-center md:justify-between md:gap-8 lg:gap-12">
          
          {/* Left Column (Desktop: Avatar, Location, Language) */}
          <div className="w-full md:w-2/5 lg:w-[36%] xl:w-1/3 flex-shrink-0 flex flex-col items-center md:items-start text-center md:text-left mb-10 md:mb-0">
            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="0ms" className="hidden md:flex w-full justify-center md:justify-start">
              <img 
                src={AVATAR_URL} 
                alt="Shounak Kshirsagar" 
                className="w-52 h-52 sm:w-56 sm:h-56 lg:w-64 lg:h-64 rounded-full object-cover shadow-2xl border-4 border-dark-bg-subtle" 
              />
            </AnimatedItem>
            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="150ms" className="hidden md:flex mt-6 items-center text-dark-text-medium">
              <MapPinIcon className="w-5 h-5 mr-2 text-sky-400" />
              <span>Pune, India</span>
            </AnimatedItem>
            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="300ms" className="hidden md:flex mt-4 space-x-2">
              <button className="px-3 py-1 text-sm border border-dark-text-low text-dark-text-medium rounded-full hover:bg-dark-bg-subtle transition">English</button>
              <button className="px-3 py-1 text-sm border border-dark-text-low text-dark-text-medium rounded-full hover:bg-dark-bg-subtle transition">हिन्दी</button>
            </AnimatedItem>
          </div>

          {/* Right Column (Desktop) / Main Content (Mobile) */}
          <div className="w-full md:w-3/5 lg:w-[64%] xl:w-2/3">
            {/* Mobile Top Info Block (Avatar, Location, Language) */}
            <div className="md:hidden flex flex-col items-center text-center mb-8">
              <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="0ms">
                <img src={AVATAR_URL} alt="Shounak Kshirsagar" className="w-32 h-32 rounded-full object-cover shadow-xl border-2 border-dark-bg-subtle mb-4" />
              </AnimatedItem>
              <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="50ms" className="flex items-center text-dark-text-medium text-sm">
                <MapPinIcon className="w-4 h-4 mr-1.5 text-sky-400" /> Pune, India
              </AnimatedItem>
              <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="100ms" className="mt-2 flex space-x-2">
                <button className="px-2.5 py-0.5 text-xs border border-dark-text-low text-dark-text-medium rounded-full hover:bg-dark-bg-subtle transition">English</button>
                <button className="px-2.5 py-0.5 text-xs border border-dark-text-low text-dark-text-medium rounded-full hover:bg-dark-bg-subtle transition">हिन्दी</button>
              </AnimatedItem>
            </div>

            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="150ms" className="flex justify-center md:justify-end mb-6 md:mb-8">
              <a 
                href="#contact" 
                onClick={smoothScrollTo('#contact')} 
                className="inline-flex items-center bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium px-4 py-2.5 rounded-full shadow-lg transition group"
                role="button"
              >
                <CalendarDaysIcon className="w-5 h-5 mr-2" />
                Schedule a call
                <ChevronRightIcon className="w-5 h-5 ml-1.5 transform transition-transform group-hover:translate-x-0.5" />
              </a>
            </AnimatedItem>

            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="200ms" className="text-center md:text-left">
              <h1 id="about-page-main-title" className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-1 sm:mb-2">
                Shounak Kshirsagar
              </h1>
            </AnimatedItem>

            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="250ms" className="text-center md:text-left">
              <p className="text-lg sm:text-xl text-dark-text-medium mb-6 md:mb-8">
                Supply Chain Engineer &bull; Procurement Strategist &bull; Digital Tools Builder
              </p>
            </AnimatedItem>

            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="300ms" className="flex justify-center md:justify-start space-x-2 sm:space-x-3 mb-6 md:mb-8">
              <a href={GITHUB_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-dark-text-medium hover:text-white bg-dark-bg-card hover:bg-slate-700/60 px-3 py-1.5 rounded-full text-xs sm:text-sm transition-colors group">
                <GitHubIcon className="w-4 h-4 sm:w-5 sm:h-5 mr-1.5 sm:mr-2" /> GitHub
              </a>
              <a href={LINKEDIN_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-dark-text-medium hover:text-white bg-dark-bg-card hover:bg-slate-700/60 px-3 py-1.5 rounded-full text-xs sm:text-sm transition-colors group">
                <LinkedInIcon className="w-4 h-4 sm:w-5 sm:h-5 mr-1.5 sm:mr-2" /> LinkedIn
              </a>
              <a href="#contact" onClick={smoothScrollTo('#contact')} className="inline-flex items-center text-dark-text-medium hover:text-white bg-dark-bg-card hover:bg-slate-700/60 px-3 py-1.5 rounded-full text-xs sm:text-sm transition-colors group">
                <EnvelopeIconLocal className="w-4 h-4 sm:w-5 sm:h-5 mr-1.5 sm:mr-2" /> Email
              </a>
            </AnimatedItem>

            <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="350ms" className="text-center md:text-left">
              <p className="text-md sm:text-lg text-dark-text-medium leading-relaxed max-w-xl mx-auto md:mx-0">
                I optimize supply chains through strategic procurement and innovative digital solutions, transforming complex challenges into elegant, data-driven outcomes.
              </p>
            </AnimatedItem>
          </div>
        </div>
      </div>
    </div>
  );
};


// --- Skills Sub-Section ---
interface Skill {
  name: string;
  description: string;
  icon: React.ReactElement;
}
const skillsData: Skill[] = [
  {
    name: "Supply Chain Optimization",
    description: "Streamlining end-to-end processes for enhanced efficiency, cost reduction, and resilience.",
    icon: <CubeTransparentIcon className="w-10 h-10 sm:w-12 sm:h-12 text-brand-primary" />
  },
  {
    name: "Strategic Procurement",
    description: "Developing robust sourcing strategies and supplier relationships to maximize value and mitigate risks.",
    icon: <ShoppingBagIcon className="w-10 h-10 sm:w-12 sm:h-12 text-brand-primary" />
  },
  {
    name: "Digital Tool Development",
    description: "Building custom analytics dashboards, automation scripts, and decision-support tools for operational excellence.",
    icon: <CommandLineIcon className="w-10 h-10 sm:w-12 sm:h-12 text-brand-primary" />
  },
];

const SkillCard: React.FC<{ skill: Skill; prefersReducedMotion: boolean; delay: string }> = ({ skill, prefersReducedMotion, delay }) => {
  const transformClass = prefersReducedMotion ? '' : 'group-hover:transform group-hover:-translate-y-1.5 group-hover:scale-[1.02]';
  const shadowClass = prefersReducedMotion ? '' : 'hover:shadow-2xl hover:shadow-brand-primary/10';

  return (
    <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay={delay} threshold={0.2} className="h-full">
      <div className={`group bg-dark-bg-card p-6 sm:p-8 rounded-xl shadow-lg text-dark-text-high h-full flex flex-col transition-all duration-300 ease-out ${shadowClass} ${transformClass}`}>
        <div className="mb-5 flex justify-center items-center w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-dark-bg-subtle p-2 mx-auto">
          {skill.icon}
        </div>
        <h3 className="text-xl sm:text-2xl font-semibold text-center text-white mb-3">{skill.name}</h3>
        <p className="text-dark-text-medium text-sm sm:text-base text-center leading-relaxed flex-grow">{skill.description}</p>
      </div>
    </AnimatedItem>
  );
};

const SkillsSubSection: React.FC<{ prefersReducedMotion: boolean }> = ({ prefersReducedMotion }) => {
  return (
    <div className="py-16 md:py-24 bg-dark-bg-subtle text-dark-text-high">
      <div className="container mx-auto px-6 md:px-8 max-w-6xl">
        <AnimatedItem prefersReducedMotion={prefersReducedMotion} className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl font-semibold text-white mb-4">Skills & Focus Areas</h2>
          <p className="text-lg text-dark-text-medium max-w-2xl mx-auto">
            Leveraging a blend of engineering principles and modern technology to solve complex supply chain challenges.
          </p>
        </AnimatedItem>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {skillsData.map((skill, index) => (
            <SkillCard key={skill.name} skill={skill} prefersReducedMotion={prefersReducedMotion} delay={`${index * 150}ms`} />
          ))}
        </div>
      </div>
    </div>
  );
};

// --- Journey Sub-Section (Timeline) ---
interface JourneyMilestone {
  id: string;
  date: string; 
  title: string;
  description: string;
  // icon?: React.ReactNode; // Icon was part of the detailedCard, removing for reversion
}

const journeyMilestones: JourneyMilestone[] = [
  {
    id: 'education-bs',
    date: '2010 - 2014', // Example, adjust as needed
    title: 'B.S. Industrial Engineering',
    description: 'Focused on process optimization and operational efficiency during my undergraduate studies. Developed a strong foundation in data analysis and system design.',
  },
  {
    id: 'early-industry',
    date: '2014 - 2016',
    title: 'Initial Industry Exposure',
    description: 'Gained practical experience in manufacturing and logistics, implementing early process improvements and learning shop-floor dynamics.',
  },
  {
    id: 'grad-school-ms',
    date: '2016 - 2018',
    title: 'M.S. Industrial Engineering, Georgia Tech',
    description: 'Specialized in supply chain management, focusing on digital transformation, advanced analytics, and data-driven strategies for global operations.',
  },
  {
    id: 'industry-impact',
    date: '2018 - Present',
    title: 'Supply Chain Strategist & Consultant',
    description: 'Led digitization initiatives, developed cost-saving procurement tools, and designed resilient supply networks, achieving multi-million dollar impacts for various clients.',
  },
  {
    id: 'current-focus',
    date: 'Ongoing',
    title: 'Freelance Consultant & Tool Builder',
    description: 'Innovating with tech startup agility, delivering custom digital tools and data-driven solutions for businesses aiming for supply chain excellence.',
  },
];

const JourneyItem: React.FC<{ item: JourneyMilestone; index: number; prefersReducedMotion: boolean; isLast: boolean }> = ({ item, index, prefersReducedMotion, isLast }) => {
  const side = index % 2 === 0 ? 'left' : 'right';

  // Default rendering for standard timeline items (this is now the only rendering path)
  return (
    <AnimatedItem 
      prefersReducedMotion={prefersReducedMotion} 
      delay={`${index * 150}ms`}
      initialX={prefersReducedMotion ? 0 : (side === 'left' ? -20 : 20)}
      initialY={0} // No Y offset for default items unless desired
      className="relative md:flex md:items-start"
    >
      {/* Desktop timeline connectors */}
      <div className={`hidden md:block absolute top-2 ${side === 'left' ? 'right-1/2 -mr-2.5' : 'left-1/2 -ml-2.5'} w-5 h-5 rounded-full bg-brand-cta-blue border-2 border-dark-bg-main shadow-md z-10`}></div>
      {!isLast && <div className={`hidden md:block absolute top-5 h-full w-0.5 ${side === 'left' ? 'right-1/2' : 'left-1/2'} bg-brand-cta-blue/50`}></div>}
      
      {/* Content Box */}
      <div className={`w-full md:w-[calc(50%-1.25rem)] p-6 bg-dark-bg-card rounded-lg shadow-xl mb-8 md:mb-0 ${side === 'left' ? 'md:mr-auto' : 'md:ml-auto'}`}>
        <p className="text-sm text-brand-cta-blue font-semibold mb-1">{item.date}</p>
        <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
        <p className="text-sm text-dark-text-medium leading-relaxed">{item.description}</p>
      </div>
    </AnimatedItem>
  );
};


const JourneySubSection: React.FC<{ prefersReducedMotion: boolean }> = ({ prefersReducedMotion }) => {
  return (
    <div className="py-16 md:py-24 text-dark-text-high bg-dark-bg-main">
      <div className="container mx-auto px-6 md:px-8 max-w-4xl">
        <AnimatedItem prefersReducedMotion={prefersReducedMotion} className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl font-semibold text-white mb-4">My Journey</h2>
          <p className="text-lg text-dark-text-medium max-w-2xl mx-auto">
            A timeline of key experiences and milestones that have shaped my expertise.
          </p>
        </AnimatedItem>
        
        {/* Mobile Timeline */}
        <div className="md:hidden relative pl-6 border-l-2 border-brand-cta-blue/50">
           {journeyMilestones.map((item, index) => (
             <AnimatedItem 
                key={item.id}
                prefersReducedMotion={prefersReducedMotion}
                delay={`${index * 100}ms`}
                className="mb-8 relative"
              >
                {/* Mobile timeline dot */}
                <div className="absolute -left-[calc(0.75rem+1px)] top-1 w-3 h-3 rounded-full bg-brand-cta-blue border border-dark-bg-main"></div>
                {/* Mobile content box */}
                <div className="ml-2 p-4 bg-dark-bg-card rounded-md shadow-lg">
                    <p className="text-xs text-brand-cta-blue font-semibold mb-0.5">{item.date}</p>
                    <h3 className="text-md font-semibold text-white mb-1">{item.title}</h3>
                    <p className="text-xs text-dark-text-medium leading-normal">{item.description}</p>
                </div>
             </AnimatedItem>
           ))}
        </div>

        {/* Desktop Timeline */}
        <div className="hidden md:block relative space-y-12">
          {journeyMilestones.map((item, index) => (
            <JourneyItem 
              key={item.id} 
              item={item} 
              index={index} 
              prefersReducedMotion={prefersReducedMotion} 
              isLast={index === journeyMilestones.length - 1}
            />
          ))}
        </div>
      </div>
    </div>
  );
};


// --- CTA Sub-Section ---
const CtaSubSection: React.FC<{ prefersReducedMotion: boolean; smoothScrollTo: (selector: string) => (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => void; }> = ({ prefersReducedMotion, smoothScrollTo }) => {
  return (
    <div className="py-16 md:py-24 text-dark-text-high bg-dark-bg-subtle">
      <div className="container mx-auto px-6 md:px-8 max-w-3xl text-center">
        <AnimatedItem prefersReducedMotion={prefersReducedMotion} className="mb-8">
          <h2 className="text-3xl sm:text-4xl font-semibold text-white mb-4">Ready to Optimize Your Supply Chain?</h2>
          <p className="text-lg text-dark-text-medium leading-relaxed">
            Let's connect to discuss how my expertise can drive impactful results for your business, or explore the custom tools I've developed.
          </p>
        </AnimatedItem>
        <AnimatedItem prefersReducedMotion={prefersReducedMotion} delay="150ms" className="flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-6">
          <a
            href="#tools"
            onClick={smoothScrollTo('#tools')}
            className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-brand-cta-blue bg-white hover:bg-gray-100 transition-colors duration-300 shadow-md hover:shadow-lg"
            role="button"
          >
            View My Tools
            <ArrowRightCircleIcon />
          </a>
          <a
            href="#contact"
            onClick={smoothScrollTo('#contact')}
            className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-brand-cta-blue hover:bg-blue-700 transition-colors duration-300 shadow-md hover:shadow-lg"
            role="button"
          >
            Book a Consultation
            <ArrowRightCircleIcon />
          </a>
        </AnimatedItem>
      </div>
    </div>
  );
};


// --- Main AboutSection Component ---
const AboutSection: React.FC = () => {
  const prefersReducedMotion = usePrefersReducedMotion();

  const smoothScrollTo = (selector: string) => (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => {
    e.preventDefault();
    const targetElement = document.querySelector(selector);
    if (targetElement) {
      // Consider header offset if you have a fixed header
      const headerOffset = (document.querySelector('header.fixed') as HTMLElement)?.offsetHeight || 0;
      const elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - headerOffset - 20; // 20px buffer

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <SectionWrapper 
      id="about" 
      className="bg-dark-bg-main !py-0 text-dark-text-high" 
      ariaLabelledBy="about-page-main-title" 
    >
      <IntroSubSection prefersReducedMotion={prefersReducedMotion} smoothScrollTo={smoothScrollTo} />
      <SkillsSubSection prefersReducedMotion={prefersReducedMotion} />
      <JourneySubSection prefersReducedMotion={prefersReducedMotion} />
      <CtaSubSection prefersReducedMotion={prefersReducedMotion} smoothScrollTo={smoothScrollTo} />
    </SectionWrapper>
  );
};

export default AboutSection;
