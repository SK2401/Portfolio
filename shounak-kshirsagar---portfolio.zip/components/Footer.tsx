import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="fixed bottom-0 left-0 w-full bg-slate-900 text-gray-400 py-4 px-6 z-40 shadow-t-md">
      <div className="container mx-auto text-center text-sm">
        <p>&copy; {currentYear} Shounak Kshirsagar. All rights reserved.</p>
        {/* You can add more links or info here if needed, e.g.,
        <p className="mt-1">
          <a href="#privacypolicy" className="hover:text-gray-200 transition-colors">Privacy Policy</a> | 
          <a href="#terms" className="hover:text-gray-200 transition-colors">Terms of Service</a>
        </p> 
        */}
      </div>
    </footer>
  );
};

export default Footer;